
import React from 'react';
import {
  KeyboardArrowDown as KeyboardArrowDownIcon,
  ControlPoint as ControlPointIcon,
  Done as DoneIcon,
  MusicNote as MusicNoteIcon,
  Headphones as HeadphonesIcon,
  Person as PersonIcon,
  InsertDriveFile as InsertDriveFileIcon,
  AutoAwesomeMotion as AutoAwesomeMotionIcon,
  Radio as RadioIcon,
  Group as GroupIcon,
  PlayArrow as PlayArrowIcon,
  Reorder as ReorderIcon,
  SkipNext as SkipNextIcon,
  SkipPrevious as SkipPreviousIcon,
  Loop as LoopIcon,
  Shuffle as ShuffleIcon,
  VolumeUp as VolumeUpIcon,
  Add as AddIcon,
  CallMissedOutgoing as CallMissedOutgoingIcon,
  GridView as GridViewIcon,
  List as ListIcon,
} from '@mui/icons-material';
import VolumeSlider from './VolumeSlider';
import MusicSlider from './MusicSlider';
import PlaylistNavBar from './PlaylistNavBar';
import Tabs from './PlaylistNavBar';
const Body = () => {
  const renderTab = () => {
    document.querySelectorAll('.tab-pane').forEach(el => {
      if (el.classList.contains('active')) {
        el.classList.remove('active');
      } else {
        el.classList.add('active');
      }
    })
    console.log(document.querySelectorAll(".nav-item-lol"))
    document.querySelectorAll(".nav-item-lol").forEach(el => {
      if (el.classList.contains('active')) {
        el.classList.remove('active');
      } else {
        el.classList.add('active');
      }
    })
  }
  return (
    <>
      <section className="allMenu">
        <section className="leftBar" >
          <div class="content__left">
            <section class="navigation">
              <PlaylistNavBar
                url={'#main'}
                title={'Main'}
                id={'main'}
                tracks={[
                  {
                    url: '#',
                    title: 'Browse',
                    icon: AutoAwesomeMotionIcon
                  },
                  {
                    url: '#',
                    title: 'Activity',
                    icon: GroupIcon
                  },
                  {
                    url: '#',
                    title: 'Radio',
                    icon: RadioIcon
                  },
                ]}

              />
              <PlaylistNavBar
                url={'#yourMusic'}
                title={'YourMusic'}
                id={'yourMusic'}
                tracks={[
                  {
                    url: '#',
                    title: 'Songs',
                    icon: HeadphonesIcon
                  },
                  {
                    url: '#',
                    title: 'Songs',
                    icon: MusicNoteIcon
                  },
                  {
                    url: '#',
                    title: 'Songs',
                    icon: PersonIcon
                  },
                  {
                    url: '#',
                    title: 'Songs',
                    icon: InsertDriveFileIcon
                  },
                ]}

              />
              <PlaylistNavBar
                url={'#playlists'}
                title={'Playlist'}
                id={'playlists'}
                tracks={[
                  {
                    url: '#',
                    title: 'Doo Wop'
                  },
                  {
                    url: '#',
                    title: 'Pop Classics'
                  },
                  {
                    url: '#',
                    title: 'Love $ongs'
                  },
                  {
                    url: '#',
                    title: 'Hipster'
                  },
                  {
                    url: '#',
                    title: 'New Music Friday'
                  },
                  {
                    url: '#',
                    title: 'Techno Poppers'
                  },
                  {
                    url: '#',
                    title: 'Summer Soothers'
                  },
                  {
                    url: '#',
                    title: 'Hard Rap'
                  },
                  {
                    url: '#',
                    title: 'Pop Rap'
                  },
                  {
                    url: '#',
                    title: '5 Stars'
                  },
                  {
                    url: '#',
                    title: 'Dope Dancin'
                  },
                  {
                    url: '#',
                    title: 'Sleep'
                  }
                ]}
              />

            </section>



            <section class="playlist">
              <a>
                <button>
                  <ControlPointIcon className="contrPointIcon"></ControlPointIcon>
                </button>
                New Playlist
              </a>
            </section>

            <section class="playing">
              <div class="playing__art">
                <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/cputh.jpg" alt="Album Art" />
              </div>
              <div class="playing__song">
                <a class="playing__song__name">Some Type of Love</a>
                <a class="playing__song__artist">Charlie Puth</a>
              </div>
              <div class="playing__add">
                <button>
                  <DoneIcon className="btnDI"></DoneIcon>
                </button>
              </div>
            </section>
          </div>

        </section>
        <section className="mainBar">
          <div class="content__middle">

            <div class="artist is-verified">

              <div class="artist__header">

                <div class="artist__listeners">

                  <div class="artist__listeners__count">15,662,810</div>

                  <div class="artist__listeners__label">Monthly Listeners</div>

                </div>

                <div class="artist__info">

                  <div class="profile__img">
                    <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/g_eazy_propic.jpg" alt="G-Eazy" />
                    <div className="checkMark">
                    </div>
                    <DoneIcon className="btnCheckMark"></DoneIcon>

                  </div>

                  <div class="artist__info__meta">

                    <div class="artist__info__type">Artist</div>

                    <div class="artist__info__name">G-Eazy</div>

                    <div class="artist__info__actions">

                      <button className="button-dark">
                        <div className="text-button-start">
                          <PlayArrowIcon className="btnPAI"></PlayArrowIcon>
                          Play
                        </div>
                      </button>

                      <button className="button-light">

                        Follow
                      </button>

                      <button className="button-light more">
                        ...
                      </button>

                    </div>

                  </div>


                </div>



                <div class="artist__navigation">

                  <ul class="nav nav-tabs" role="tablist">

                    <li role="presentation" class="nav-item-lol active">
                      <a aria-controls="artist-overview" role="tab" data-toggle="tab" onClick={renderTab}>Overview</a>
                    </li>

                    <li role="presentation" class="nav-item-lol">
                      <a aria-controls="related-artists" role="tab" onClick={renderTab} data-toggle="tab">Related Artists</a>
                    </li>

                  </ul>

                  <div class="artist__navigation__friends">

                    <a href="#">
                      <img src="http://zblogged.com/wp-content/uploads/2015/11/17.jpg" alt="" />
                    </a>

                    <a href="#">
                      <img src="http://zblogged.com/wp-content/uploads/2015/11/5.png" alt="" />
                    </a>

                    <a href="#">
                      <img src="http://cdn.devilsworkshop.org/files/2013/01/enlarged-facebook-profile-picture.jpg" alt="" />
                    </a>

                  </div>

                </div>

              </div>

              <div class="artist__content">

                <div class="tab-content">


                  <div role="tabpanel" class="tab-pane active" id="artist-overview">

                    <div class="overview">

                      <div class="overview__artist">


                        <div class="section-title">Latest Release</div>

                        <div class="latest-release">

                          <div class="latest-release__art">

                            <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/whenDarkOut.jpg" alt="When It's Dark Out" />

                          </div>
                          <div class="latest-release__song">

                            <div class="latest-release__song__title">Drifting (Track Commentary)</div>

                            <div class="latest-release__song__date">

                              <span class="day">4</span>

                              <span class="month">December</span>

                              <span class="year">2015</span>

                            </div>

                          </div>

                        </div>

                        <div class="section-title">Popular</div>

                        <div class="tracks">

                          <div class="track">

                            <div class="track__art">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/whenDarkOut.jpg" alt="When It's Dark Out" />

                            </div>

                            <div class="track__number">1</div>

                            <div class="track__added">

                              <DoneIcon className="trackAdd"></DoneIcon>

                            </div>

                            <div class="track__title">Me, Myself and I</div>

                            <div class="track__explicit">

                              <span class="label">Explicit</span>

                            </div>

                            <div class="track__plays">147,544,165</div>

                          </div>

                          <div class="track">

                            <div class="track__art">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/tth.jpg" alt="These Things Happen" />

                            </div>

                            <div class="track__number">2</div>

                            <div class="track__added">

                              <AddIcon className="trackAdd"></AddIcon>
                            </div>

                            <div class="track__title">I Mean It</div>

                            <div class="track__explicit">

                              <span class="label">Explicit</span>

                            </div>

                            <div class="track__plays">74,568,782</div>

                          </div>

                          <div class="track">

                            <div class="track__art">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/whenDarkOut.jpg" alt="When It's Dark Out" />

                            </div>

                            <div class="track__number">3</div>

                            <div class="track__added">

                              <DoneIcon className="trackAdd"></DoneIcon>

                            </div>

                            <div class="track__title">Calm Down</div>

                            <div class="track__explicit">

                              <span class="label">Explicit</span>

                            </div>

                            <div class="track__plays">13,737,506</div>

                          </div>

                          <div class="track">

                            <div class="track__art">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/whenDarkOut.jpg" alt="When It's Dark Out" />

                            </div>

                            <div class="track__number">4</div>

                            <div class="track__added">

                              <AddIcon className="trackAdd"></AddIcon>

                            </div>

                            <div class="track__title">Some Kind Of Drug</div>

                            <div class="track__explicit">

                              <span class="label">Explicit</span>

                            </div>

                            <div class="track__plays">12,234,881</div>

                          </div>

                          <div class="track">

                            <div class="track__art">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/tth.jpg" alt="These Things Happen" />

                            </div>

                            <div class="track__number">5</div>

                            <div class="track__added">

                              <DoneIcon className="trackAdd"></DoneIcon>
                            </div>

                            <div class="track__title">Let's Get Lost</div>

                            <div class="track__explicit">

                              <span class="label">Explicit</span>

                            </div>

                            <div class="track__plays">40,882,954</div>

                          </div>

                        </div>
                        <div className="show-more">
                          <button class="button-light">Show 5 More</button>
                        </div>

                      </div>

                      <div class="overview__related">

                        <div class="section-title">Related Artists</div>

                        <div class="related-artists">

                          <a href="#" class="related-artist">

                            <div class="related-artist__img">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/hoodie.jpg" alt="Hoodie Allen" />

                            </div>

                            <div class="related-artist__name">Hoodie Allen</div>

                          </a>

                          <a href="#" class="related-artist">

                            <div class="related-artist__img">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/mikestud.jpg" alt="Mike Stud" />

                            </div>

                            <div class="related-artist__name">Mike Stud</div>

                          </a>

                          <a href="#" class="related-artist">

                            <div class="related-artist__img">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/drake.jpeg" alt="Drake" />

                            </div>

                            <div class="related-artist__name">Drake</div>

                          </a>

                          <a href="#" class="related-artist">

                            <div class="related-artist__img">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/jcole.jpg" alt="J. Cole" />

                            </div>

                            <div class="related-artist__name">J. Cole</div>

                          </a>

                          <a href="#" class="related-artist">

                            <div class="related-artist__img">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/bigsean.jpg" alt="Big Sean" />

                            </div>

                            <div class="related-artist__name">Big Sean</div>

                          </a>

                          <a href="#" class="related-artist">

                            <div class="related-artist__img">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/wiz.jpeg" alt="Wiz Khalifa" />

                            </div>

                            <div class="related-artist__name">Wiz Khalifa</div>

                          </a>

                          <a href="#" class="related-artist">

                            <div class="related-artist__img">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/yonas.jpg" alt="Yonas" />

                            </div>

                            <div class="related-artist__name">Yonas</div>

                          </a>

                        </div>

                      </div>

                      <div class="overview__albums">

                        <div class="overview__albums__head">

                          <div class="section-title">Albums</div>

                          <span class="view-type">
                            <ListIcon className="listIcons"></ListIcon >
                            <GridViewIcon className="listIcons"> </GridViewIcon>
                          </span>

                        </div>

                        <div class="album">

                          <div class="album__info">

                            <div class="album__info__art">

                              <img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/7022/whenDarkOut.jpg" alt="When It's Dark Out" />

                            </div>

                            <div class="album__info__meta">

                              <div class="album__year">2015</div>

                              <div class="album__name">When It's Dark Out</div>

                              <div class="album__actions">

                                <button class="button-light save">Save</button>

                                <button class="button-light more">
                                  ...
                                </button>

                              </div>

                            </div>

                          </div>

                          <div class="album__tracks">

                            <div class="tracks">

                              <div class="tracks__heading">

                                <div class="tracks__heading__number">#</div>

                                <div class="tracks__heading__title">Song</div>

                                <div class="tracks__heading__length">



                                </div>

                                <div class="tracks__heading__popularity">


                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">1</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title">Intro</div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">1:11</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">2</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>


                                </div>

                                <div class="track__title">Random</div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">3:00</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">3</div>

                                <div class="track__added">
                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">Me, Myself and I</span>
                                  <span class="feature">Bebe Rexha</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">4:11</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">4</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">One Of Them</span>
                                  <span class="feature">Big Sean</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">3:20</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>
                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">5</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">Drifting</span>
                                  <span class="feature">Chris Brown</span>
                                  <span class="feature">Tory Lanez</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">4:33</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">6</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">Of All Things</span>
                                  <span class="feature">Too $hort</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">3:34</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">7</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">Order More</span>
                                  <span class="feature">Starrah</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">3:29</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">8</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title">

                                  <span>Calm Down</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">2:07</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">9</div>

                                <div class="track__added">

                                  <AddIcon className="trackAdd"></AddIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">Don't Let Me Go</span>
                                  <span class="feature">Grace</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">3:11</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">10</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title">

                                  <span>You Got Me</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">3:28</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">11</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">What If</span>
                                  <span class="feature">Gizzle</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">4:13</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">12</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title">

                                  <span>Sad Boy</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">3:23</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">13</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>


                                </div>

                                <div class="track__title featured">

                                  <span class="title">Some Kind Of Drug</span>
                                  <span class="feature">Marc E. Bassy</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">3:42</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">14</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">Think About You</span>
                                  <span class="feature">Quin</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">2:59</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">15</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>


                                </div>

                                <div class="track__title featured">

                                  <span class="title">Everything Will Be OK</span>
                                  <span class="feature">Kehlani</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">5:11</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">16</div>

                                <div class="track__added">

                                  <DoneIcon className="trackAdd"></DoneIcon>


                                </div>

                                <div class="track__title featured">

                                  <span class="title">For This</span>
                                  <span class="feature">Iamnobodi</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">4:11</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                              <div class="track">

                                <div class="track__number">17</div>

                                <div class="track__added">
                                  <DoneIcon className="trackAdd"></DoneIcon>

                                </div>

                                <div class="track__title featured">

                                  <span class="title">Nothing to Me</span>
                                  <span class="feature">Keyshia Cole</span>
                                  <span class="feature">E-40</span>

                                </div>

                                <div class="track__explicit">

                                  <span class="label">Explicit</span>

                                </div>

                                <div class="track__length">5:30</div>

                                <div class="track__popularity">

                                  <CallMissedOutgoingIcon className="trackAdd"></CallMissedOutgoingIcon>

                                </div>

                              </div>

                            </div>

                          </div>

                        </div>

                      </div>

                    </div>

                  </div>
                  <div role="tabpanel" class="tab-pane" id="related-artists">

                    <div class="media-cards">

                      <div class="media-card">

                        <div class="media-card__image" >

                          <i class="ion-ios-play"></i>

                        </div>

                        <a class="media-card__footer">Hoodie Allen</a>

                      </div>

                      <div class="media-card">

                        <div class="media-card__image" >

                          <i class="ion-ios-play"></i>

                        </div>

                        <a class="media-card__footer">Mike Stud</a>

                      </div>

                      <div class="media-card">

                        <div class="media-card__image" >

                          <i class="ion-ios-play"></i>

                        </div>

                        <a class="media-card__footer">Drake</a>

                      </div>

                      <div class="media-card">

                        <div class="media-card__image">

                          <i class="ion-ios-play"></i>

                        </div>

                        <a class="media-card__footer">J. Cole</a>

                      </div>

                      <div class="media-card">

                        <div class="media-card__image" >

                          <i class="ion-ios-play"></i>

                        </div>

                        <a class="media-card__footer">Big Sean</a>

                      </div>

                      <div class="media-card">

                        <div class="media-card__image" >

                          <i class="ion-ios-play"></i>

                        </div>

                        <a class="media-card__footer">Wiz Khalifa</a>

                      </div>

                      <div class="media-card">

                        <div class="media-card__image">

                          <i class="ion-ios-play"></i>

                        </div>

                        <a class="media-card__footer">Yonas</a>

                      </div>

                      <div class="media-card">

                        <div class="media-card__image">

                          <i class="ion-ios-play"></i>

                        </div>

                        <a class="media-card__footer">Childish Gambino</a>

                      </div>

                    </div>

                  </div>


                </div>

              </div>

            </div>

          </div>
        </section>
        <section class="content__right">
          <div class="social">

            <div class="friends">

              <a href="#" class="friend">


                <PersonIcon className="btmnPI"></PersonIcon>
                Sam Smith

              </a>

              <a href="#" class="friend">

                <PersonIcon className="btmnPI"></PersonIcon>
                Tarah Forsyth

              </a>

              <a href="#" class="friend">


                <PersonIcon className="btmnPI"></PersonIcon>
                Ricahrd Tomkins

              </a>

              <a href="#" class="friend">


                <PersonIcon className="btmnPI"></PersonIcon>
                Tony Russo

              </a>

              <a href="#" class="friend">


                <PersonIcon className="btmnPI"></PersonIcon>
                Alyssa Marist

              </a>

              <a href="#" class="friend">


                <PersonIcon className="btmnPI"></PersonIcon>
                Ron Samson

              </a>

            </div>

            <button class="button-light">Find Friends</button>

          </div>

        </section>
      </section>
      <section className="current-track">


        <div class="current-track__actions">
          <SkipPreviousIcon className='skipTrackIcon'></SkipPreviousIcon>
          <PlayArrowIcon className='playTrackIcon'></PlayArrowIcon>
          <SkipNextIcon className='skipTrackIcon'></SkipNextIcon>
        </div>

        <div class="current-track__progress">

          <div class="current-track__progress__start">0:01</div>

          <div class="current-track__progress__bar">

            <MusicSlider />

          </div>

          <div class="current-track__progress__finish">3:07</div>

        </div>

        <div class="current-track__options">



          <div class="controls">
            <div class="lyrics">Lyrics</div>

            <div class="control-icon">
              <ReorderIcon className="controlIcon"></ReorderIcon>
              <ShuffleIcon className="controlIcon"></ShuffleIcon>
              <LoopIcon className="controlIcon"></LoopIcon>
            </div>

            <div class="control devices">

              <p>Devices Available</p>
            </div>

            <div class="control volume">

              <div className="volume-song">
                <VolumeUpIcon className="iconVolume"></VolumeUpIcon>
                <VolumeSlider />
              </div>

            </div>

          </div>

        </div>
      </section>
    </>

  );

}

export default Body;